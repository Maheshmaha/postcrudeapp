angular.module("postapp.directives",[])
	.directive("scrollTop", function($window, $document, $ionicScrollDelegate){
		return {
			restrict:"E",
			scope: {},
			template: "<div  class='nav_up ' id='nav_up'></div>",

			
			link: function(scope, element, attrs){
				if(attrs.contentid){
					var elem = attrs.contentid;

					$("#"+elem).bind("scroll", function(){
						var scrollpostion = $ionicScrollDelegate.getScrollPosition($(this)).top;
						if(scrollpostion > 100){
							$('.nav_up').fadeIn();
						}else{
							$('.nav_up').fadeOut();
						}
						scope.$digest();
					});


					$(element).bind("click", function(){
						 $ionicScrollDelegate.scrollTo(0,0, true);
						return false;
					});

				}

			}
		}
	})

	.directive("passwordVerify", function(){
		return {
			require: "ngModel",
			scope: {
				passwordVerify: '='
			},
			link: function(scope, element, attrs, ctrl){
				/**
			     * This function is added to the list of the $parsers.
			     * It will be executed the DOM (the view value) change.
			     * Array.unshift() put it in the beginning of the list, so
			     * it will be executed before all the other
			     */
				$scope.watch(function(){
					var combined;

					if(scope.passwordVerify|| ctlr.$viewValue){
						combined = scope.passwordVerify + '_' + ctrl.$viewValue;
					}

					return combined;
				})
			}, function(value){
				if(value){
					ctrl.$parsers.unshift(function(viewValue){
						var origin = scope.passwordVerify;
						if(origin !== viewValue){
							ctrl.$setValidity("passwordVerify", false);
							return undefined;
						}else {
							ctrl.$setValidity("passwordVerify", true);
							return viewValue;
						}
					})
				}
			}
		}	
	});