angular.module("postapp.filters",[])
	.filter("postCustomFilter", function(){
		return function(items){
			var filteredposts = [];
			angular.forEach(items, function(item){
				if(item.userId == )
			})
		}
	})

