
angular.module("postapp.services",[]).constant({
	DB_USER_URL: "https://api.mlab.com/api/1/databases/postdatabase/collections/users/:id",
	DB_POST_URL: "https://api.mlab.com/api/1/databases/postdatabase/collections/posts/:id",
	DB_COMMENTS_URL : "https://api.mlab.com/api/1/databases/postdatabase/collections/comments/:id",
	API_KEY: "MNG8Br2IMXt41EOgJKG2RlTV0ljy9Aip"
}).factory('User', function($resource, DB_USER_URL, API_KEY){
	return $resource(DB_USER_URL,{ id:'@_id.$oid', apiKey: API_KEY},
	{
		update: {
			method: 'PUT'
		}
	});
}).factory('Post', function($resource, DB_POST_URL, API_KEY){
	return $resource(DB_POST_URL,{ id:'@_id.$oid', apiKey: API_KEY},
	{
		update: {
			method: 'PUT'
		}
	});
}).factory('Comment', function($resource,DB_COMMENTS_URL, API_KEY ){
	return $resource(DB_COMMENTS_URL,{ id:'@_id.$oid', apiKey: API_KEY},
	{
		update: {
			method: 'PUT'
		}
	});
})


