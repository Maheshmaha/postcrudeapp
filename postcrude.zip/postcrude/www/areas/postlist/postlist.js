var postlist = angular.module("post.postlist", []);


postlist.controller("postListController", function($scope, Post, User, $window, $state, $ionicLoading, $ionicPopup, $q){
	
	$ionicLoading.show();
	$scope.posts = Post.query();
	$scope.users = User.query();
	$scope.posts.$promise.then(function(data){
		$scope.posts  = data;
		$ionicLoading.hide();
	}, function(error){

	});


	$scope.users.$promise.then(function(data){
		$scope.users  = data;
		console.log($scope.users);
	});

	$scope.deletePost = function(post){
		console.log(post);
		var deletePopup = $ionicPopup.confirm({
			title: 'Post app',
			template: 'Are you sure you want to delete the post'
		});

		deletePopup.then(function(res){
			if(res){
				post.$delete(function(){
					$state.go($state.current, {}, {reload: true});
				});
			}
			else{

			}
		});
	}
})
.controller("createPostController", function($scope, $state, Post, $ionicLoading, $ionicPopup){
	$scope.newpost = new Post();
	
	$scope.createPost = function(){
		$ionicLoading.show();
		$scope.newpost.$save()
				.then(function(){
					$ionicLoading.hide();
					$state.go('app.postlist', {}, { reload: true }).then(function(){
						$scope.posts = Post.query();	
						$scope.posts.$promise.then(function(data){
							$scope.posts  = data;
							
						}, function(error){

						});
					});
					
				}, function(error){

				});
	}
})

.controller("editPostController", function($scope, $state, $stateParams, Post, $ionicLoading){
		$scope.loadPost = function(){
			$scope.newpost = Post.get({id:$stateParams.id});
		}

		$scope.loadPost();

		$scope.updatePost = function(){
			$scope.newpost.$update(function(){
				$state.go('app.postlist', {}, { reload: true }).then(function(){
						$scope.posts = Post.query();	
						$scope.posts.$promise.then(function(data){
							$scope.posts = data;
							
						}, function(error){

						});
					});
			});
		};
})

.controller("postDetailController", function($scope, $state, $filter, $stateParams, Post, Comment, $ionicLoading, $ionicModal){
	$scope.postcomments = [];
	$scope.postdetail = [];
	$scope.newcomment = new Comment();
	$scope.loadDetails = function(){
		$scope.postid = $stateParams.postid;
		$scope.id = $stateParams.id;
		$scope.displaypost = Post.get({id:$stateParams.id});

		Comment.query().$promise.then(function(data){
			$scope.comments = data;
			$scope.postcomments = $filter('filter')($scope.comments, {postId: $scope.postid});
		 })

		console.log($scope.displaypost);
	}

	$scope.loadDetails();


	$scope.addComments = function(){
		$ionicModal.fromTemplateUrl("areas/postlist/createnewcomment.html",{
			scope: $scope,
			animation: 'slide-in-up'
		}).then(function(modal){
			$scope.modal=modal;
			$scope.modal.show();
		})
	}

	$scope.closeModal = function(){
		$scope.modal.hide();
	}

	$scope.addComment = function(){
		$ionicLoading.show();
		$scope.newcomment.$save()
				.then(function(){
					$ionicLoading.hide();
					$state.go('app.detailpost', {}, { reload: true }).then(function(){
						$scope.comments = Comment.query();	
						$scope.comments.$promise.then(function(data){
							$scope.comments  = data;
							$scope.loadDetails();
							$scope.modal.hide();
						}, function(error){

						});
					});
					
				}, function(error){

				});
	}
})

