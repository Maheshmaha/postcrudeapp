var menu = angular.module("post.menu",[]);


menu.controller("appController", function($scope){

});