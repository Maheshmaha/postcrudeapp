var login = angular.module("postapp.login",[]);


login.controller("loginController", function($scope,User,$filter, $state, $ionicPopup){
	$scope.login = {};
	$scope.login.users = null;
	$scope.loginsubmitted = false;
	


 $scope.login = function(isFormValid){
 	$scope.loginsubmitted = true;

 	if(isFormValid){
 		$scope.login.users = User.query();

	 	$scope.login.users.$promise.then(function(data){
	 		$scope.login.users = data;
	 		var  userdetails = $filter('filter')($scope.login.users, { username: $scope.login.username }, true)[0];
			
	 	if(userdetails && userdetails!=null){
	 		var successPopup = $ionicPopup.alert({
			     title: 'Postapp',
			     template: 'Logged in successfully'
			   });
	 		successPopup.then(function(res){
	 			$state.go("app.postlist");
	 		});
	 	}
	 	else{
	 		var errorPopup = $ionicPopup.alert({
	 			 title: 'Postapp',
			     template: 'Authentication Failed'
	 		});

	 		return false;
	 	}

	 	}, function(error){

	 	});
 	}
 }

}).controller("registerController", function($scope, User){
	$scope.registersubmitted = false;
	$scope.register= {};
	$scope.register.emailFormat = /^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/;
	$scope.register.phoneFormat = /^[0-9]+$/;
	$scope.register.nameFormat = /^[a-zA-Z\s]*$/;
	$scope.newuser = new User();
	$scope.login = {};
	$scope.login.users = User.query();
	$scope.createPost = function(){
		$ionicLoading.show();
		$scope.newuser.$save()
				.then(function(){
					$ionicLoading.hide();
					$state.go('login', {}, { reload: true }).then(function(){
						$scope.login.users = User.query();	
						$scope.login.users.$promise.then(function(data){
							$scope.login.users  = data;
							
						}, function(error){

						});
					});
					
				}, function(error){

				});
	}
});