// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('postapp', ['ionic', 'ngResource','postapp.login', 'post.menu', 'post.postlist', 'postapp.services', 'postapp.directives'])

.config(["$stateProvider","$urlRouterProvider","$httpProvider","$ionicConfigProvider", function($stateProvider,$urlRouterProvider, $httpProvider, $ionicConfigProvider){

    $stateProvider
      .state("login",{
        url: '/login',
        templateUrl: 'areas/login/login.html',
        controller: 'loginController'
      })

      .state("register", {
        url: '/register',
        templateUrl: 'areas/login/register.html',
        controller: 'registerController'
      })

      .state("app",{
           url: 'app',
           abstract: true,
           templateUrl: 'areas/menu/menu.html',
           controller: 'appController',
        })

      
        .state("app.postlist", {
            url: '/postlist',
            cache: false,
              views: {
              'menuContent' :{
                templateUrl: "areas/postlist/postlist.html",
                controller: 'postListController'
              }
            }
        })

         .state("app.newpost", {
          url:'/newpost',
          views: {
            'menuContent' :{
              templateUrl: "areas/postlist/createnewpost.html",
              controller: "createPostController"
            }
          }
        })

         .state("app.editpost", {
          url:':id/editpost',
            views: {
            'menuContent' :{
              templateUrl: "areas/postlist/editpost.html",
              controller: "editPostController"
            }
          }
         })

         .state("app.detailpost", {
            url:':id/:postid/detailpost',
            views: {
              'menuContent' :{
                templateUrl: "areas/postlist/postdetail.html",
                controller: "postDetailController"
              }
            }
         })

      $urlRouterProvider.otherwise("/login");


}])




.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if(window.cordova && window.cordova.plugins.Keyboard) {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

      // Don't remove this line unless you know what you are doing. It stops the viewport
      // from snapping when text inputs are focused. Ionic handles this internally for
      // a much nicer keyboard experience.
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})
